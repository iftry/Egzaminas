import React from 'react';
import EventForm from '../components/EventForm';

const AddEvent = () => {
  return (
    <div>
      <h2>Add New Event</h2>
      <EventForm />
    </div>
  );
};

export default AddEvent;
